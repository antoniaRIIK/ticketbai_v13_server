# Translation of Odoo Server.
# This file contains the translation of the following modules:
#	* l10n_es_aeat_certificate
#
msgid ""
msgstr ""
"Project-Id-Version: Odoo Server 12.0\n"
"Report-Msgid-Bugs-To: \n"
"POT-Creation-Date: 2019-05-25 17:04+0000\n"
"PO-Revision-Date: 2019-05-25 17:04+0000\n"
"Last-Translator: <>\n"
"Language-Team: \n"
"MIME-Version: 1.0\n"
"Content-Type: text/plain; charset=UTF-8\n"
"Content-Transfer-Encoding: \n"
"Plural-Forms: \n"

#. module: l10n_es_aeat_certificate
#: selection:l10n.es.aeat.certificate,state:0
msgid "Active"
msgstr ""

#. module: l10n_es_aeat_certificate
#: model_terms:ir.ui.view,arch_db:l10n_es_aeat_certificate.l10n_es_aeat_certificate_password_wizard_view
msgid "Cancel"
msgstr ""

#. module: l10n_es_aeat_certificate
#: model:ir.actions.act_window,name:l10n_es_aeat_certificate.l10n_es_certificate_action
#: model:ir.ui.menu,name:l10n_es_aeat_certificate.l10n_es_aeat_certificate_menu
msgid "Certificates"
msgstr ""

#. module: l10n_es_aeat_certificate
#: model:ir.model.fields,field_description:l10n_es_aeat_certificate.field_l10n_es_aeat_certificate__company_id
msgid "Compañía"
msgstr ""

#. module: l10n_es_aeat_certificate
#: model:ir.model.fields,field_description:l10n_es_aeat_certificate.field_l10n_es_aeat_certificate__create_uid
#: model:ir.model.fields,field_description:l10n_es_aeat_certificate.field_l10n_es_aeat_certificate_password__create_uid
msgid "Created by"
msgstr ""

#. module: l10n_es_aeat_certificate
#: model:ir.model.fields,field_description:l10n_es_aeat_certificate.field_l10n_es_aeat_certificate__create_date
#: model:ir.model.fields,field_description:l10n_es_aeat_certificate.field_l10n_es_aeat_certificate_password__create_date
msgid "Created on"
msgstr ""

#. module: l10n_es_aeat_certificate
#: model:ir.model.fields,field_description:l10n_es_aeat_certificate.field_l10n_es_aeat_certificate__display_name
#: model:ir.model.fields,field_description:l10n_es_aeat_certificate.field_l10n_es_aeat_certificate_password__display_name
msgid "Display Name"
msgstr ""

#. module: l10n_es_aeat_certificate
#: selection:l10n.es.aeat.certificate,state:0
msgid "Draft"
msgstr ""

#. module: l10n_es_aeat_certificate
#: model:ir.model.fields,field_description:l10n_es_aeat_certificate.field_l10n_es_aeat_certificate__date_end
msgid "End Date"
msgstr ""

#. module: l10n_es_aeat_certificate
#: model:ir.model.fields,field_description:l10n_es_aeat_certificate.field_l10n_es_aeat_certificate__file
msgid "File"
msgstr ""

#. module: l10n_es_aeat_certificate
#: model:ir.model.fields,field_description:l10n_es_aeat_certificate.field_l10n_es_aeat_certificate__folder
msgid "Folder Name"
msgstr ""

#. module: l10n_es_aeat_certificate
#: model:ir.model.fields,field_description:l10n_es_aeat_certificate.field_l10n_es_aeat_certificate__id
#: model:ir.model.fields,field_description:l10n_es_aeat_certificate.field_l10n_es_aeat_certificate_password__id
msgid "ID"
msgstr ""

#. module: l10n_es_aeat_certificate
#: code:addons/l10n_es_aeat_certificate/models/aeat_certificate.py:36
#: model_terms:ir.ui.view,arch_db:l10n_es_aeat_certificate.l10n_es_aeat_certificate_password_wizard_view
#, python-format
msgid "Insert Password"
msgstr ""

#. module: l10n_es_aeat_certificate
#: model:ir.model.fields,field_description:l10n_es_aeat_certificate.field_l10n_es_aeat_certificate____last_update
#: model:ir.model.fields,field_description:l10n_es_aeat_certificate.field_l10n_es_aeat_certificate_password____last_update
msgid "Last Modified on"
msgstr ""

#. module: l10n_es_aeat_certificate
#: model:ir.model.fields,field_description:l10n_es_aeat_certificate.field_l10n_es_aeat_certificate__write_uid
#: model:ir.model.fields,field_description:l10n_es_aeat_certificate.field_l10n_es_aeat_certificate_password__write_uid
msgid "Last Updated by"
msgstr ""

#. module: l10n_es_aeat_certificate
#: model:ir.model.fields,field_description:l10n_es_aeat_certificate.field_l10n_es_aeat_certificate__write_date
#: model:ir.model.fields,field_description:l10n_es_aeat_certificate.field_l10n_es_aeat_certificate_password__write_date
msgid "Last Updated on"
msgstr ""

#. module: l10n_es_aeat_certificate
#: model_terms:ir.ui.view,arch_db:l10n_es_aeat_certificate.l10n_es_aeat_certificate_form_view
msgid "Load Certificate"
msgstr ""

#. module: l10n_es_aeat_certificate
#: model:ir.model.fields,field_description:l10n_es_aeat_certificate.field_l10n_es_aeat_certificate__name
msgid "Name"
msgstr ""

#. module: l10n_es_aeat_certificate
#: model_terms:ir.ui.view,arch_db:l10n_es_aeat_certificate.l10n_es_aeat_certificate_form_view
#: model_terms:ir.ui.view,arch_db:l10n_es_aeat_certificate.l10n_es_aeat_certificate_password_wizard_view
msgid "Obtain Keys"
msgstr ""

#. module: l10n_es_aeat_certificate
#: code:addons/l10n_es_aeat_certificate/wizards/aeat_certificate_password.py:69
#, python-format
msgid "OpenSSL version is not supported. Upgrade to 0.15 or greater."
msgstr ""

#. module: l10n_es_aeat_certificate
#: model:ir.model.fields,field_description:l10n_es_aeat_certificate.field_l10n_es_aeat_certificate_password__password
msgid "Password"
msgstr ""

#. module: l10n_es_aeat_certificate
#: model:ir.model.fields,field_description:l10n_es_aeat_certificate.field_l10n_es_aeat_certificate__private_key
msgid "Private Key"
msgstr ""

#. module: l10n_es_aeat_certificate
#: model:ir.model.fields,field_description:l10n_es_aeat_certificate.field_l10n_es_aeat_certificate__public_key
msgid "Public Key"
msgstr ""

#. module: l10n_es_aeat_certificate
#: model:ir.model.fields,field_description:l10n_es_aeat_certificate.field_l10n_es_aeat_certificate__date_start
msgid "Start Date"
msgstr ""

#. module: l10n_es_aeat_certificate
#: model:ir.model.fields,field_description:l10n_es_aeat_certificate.field_l10n_es_aeat_certificate__state
msgid "State"
msgstr ""

#. module: l10n_es_aeat_certificate
#: model_terms:ir.ui.view,arch_db:l10n_es_aeat_certificate.l10n_es_aeat_certificate_form_view
msgid "To Active"
msgstr ""

#. module: l10n_es_aeat_certificate
#: model:ir.model,name:l10n_es_aeat_certificate.model_l10n_es_aeat_certificate
msgid "l10n.es.aeat.certificate"
msgstr ""

#. module: l10n_es_aeat_certificate
#: model:ir.model,name:l10n_es_aeat_certificate.model_l10n_es_aeat_certificate_password
msgid "l10n.es.aeat.certificate.password"
msgstr ""

#. module: l10n_es_aeat_certificate
#: model_terms:ir.ui.view,arch_db:l10n_es_aeat_certificate.l10n_es_aeat_certificate_password_wizard_view
msgid "or"
msgstr ""

