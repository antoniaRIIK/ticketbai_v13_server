# Translation of Odoo Server.
# This file contains the translation of the following modules:
#	* account_cancel
#
msgid ""
msgstr ""
"Project-Id-Version: Odoo Server saas~11.5\n"
"Report-Msgid-Bugs-To: \n"
"POT-Creation-Date: 2018-09-18 09:49+0000\n"
"PO-Revision-Date: 2018-09-18 09:49+0000\n"
"Last-Translator: <>\n"
"Language-Team: \n"
"MIME-Version: 1.0\n"
"Content-Type: text/plain; charset=UTF-8\n"
"Content-Transfer-Encoding: \n"
"Plural-Forms: \n"

#. module: account_cancel
#: model:ir.model,name:account_cancel.model_account_bank_statement
msgid "Bank Statement"
msgstr ""

#. module: account_cancel
#: model_terms:ir.ui.view,arch_db:account_cancel.invoice_form_cancel_inherit
#: model_terms:ir.ui.view,arch_db:account_cancel.invoice_supplier_cancel_form_inherit
#: model_terms:ir.ui.view,arch_db:account_cancel.payment_cancel_form_inherit
msgid "Cancel"
msgstr ""

#. module: account_cancel
#: model_terms:ir.ui.view,arch_db:account_cancel.view_move_form_inherit_account_cancel
msgid "Cancel Entry"
msgstr ""

#. module: account_cancel
#: model_terms:ir.ui.view,arch_db:account_cancel.bank_statement_draft_form_inherit
msgid "Reset to New"
msgstr ""

#. module: account_cancel
#: model_terms:ir.ui.view,arch_db:account_cancel.bank_statement_cancel_form_inherit
msgid "Revert reconciliation"
msgstr ""

