* NaN·Tic
* Roberto Lizana <roberto.lizana@trey.es>
* `Tecnativa <https://www.tecnativa.com>`__:

  * Pedro M. Baeza <pedro.baeza@tecnativa.com>
