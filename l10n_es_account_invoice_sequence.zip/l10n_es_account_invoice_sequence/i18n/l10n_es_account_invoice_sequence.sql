# Translation of Odoo Server.
# This file contains the translation of the following modules:
#	* l10n_es_account_invoice_sequence
#
msgid ""
msgstr ""
"Project-Id-Version: Odoo Server 12.0\n"
"Report-Msgid-Bugs-To: \n"
"Last-Translator: <>\n"
"Language-Team: \n"
"MIME-Version: 1.0\n"
"Content-Type: text/plain; charset=UTF-8\n"
"Content-Transfer-Encoding: \n"
"Plural-Forms: \n"

#. module: l10n_es_account_invoice_sequence
#: code:addons/l10n_es_account_invoice_sequence/models/account_chart_template.py:55
#, python-format
msgid " (Refund)"
msgstr ""

#. module: l10n_es_account_invoice_sequence
#: model:ir.model,name:l10n_es_account_invoice_sequence.model_account_chart_template
msgid "Account Chart Template"
msgstr ""

#. module: l10n_es_account_invoice_sequence
#: model:ir.model,name:l10n_es_account_invoice_sequence.model_account_invoice
msgid "Invoice"
msgstr ""

#. module: l10n_es_account_invoice_sequence
#: model:ir.model.fields,field_description:l10n_es_account_invoice_sequence.field_account_invoice__invoice_number
msgid "Invoice Number"
msgstr ""

#. module: l10n_es_account_invoice_sequence
#: model:ir.model.fields,field_description:l10n_es_account_invoice_sequence.field_account_bank_statement_import_journal_creation__invoice_sequence_id
#: model:ir.model.fields,field_description:l10n_es_account_invoice_sequence.field_account_journal__invoice_sequence_id
msgid "Invoice sequence"
msgstr ""

#. module: l10n_es_account_invoice_sequence
#: model:ir.model,name:l10n_es_account_invoice_sequence.model_account_journal
msgid "Journal"
msgstr ""

#. module: l10n_es_account_invoice_sequence
#: code:addons/l10n_es_account_invoice_sequence/hooks.py:20
#: code:addons/l10n_es_account_invoice_sequence/models/account_chart_template.py:18
#: code:addons/l10n_es_account_invoice_sequence/models/account_chart_template.py:42
#, python-format
msgid "Journal Entries Sequence"
msgstr ""

#. module: l10n_es_account_invoice_sequence
#: code:addons/l10n_es_account_invoice_sequence/models/account_journal.py:29
#, python-format
msgid "Journal company and invoice sequence company do not match."
msgstr ""

#. module: l10n_es_account_invoice_sequence
#: code:addons/l10n_es_account_invoice_sequence/models/account_journal.py:39
#, python-format
msgid "Journal company and refund sequence company do not match."
msgstr ""

#. module: l10n_es_account_invoice_sequence
#: model:ir.model.fields,field_description:l10n_es_account_invoice_sequence.field_account_invoice__number
msgid "Number"
msgstr ""

#. module: l10n_es_account_invoice_sequence
#: model:ir.model.fields,field_description:l10n_es_account_invoice_sequence.field_account_bank_statement_import_journal_creation__refund_inv_sequence_id
#: model:ir.model.fields,field_description:l10n_es_account_invoice_sequence.field_account_journal__refund_inv_sequence_id
msgid "Refund sequence"
msgstr ""

#. module: l10n_es_account_invoice_sequence
#: model:ir.model,name:l10n_es_account_invoice_sequence.model_ir_sequence
msgid "Sequence"
msgstr ""

#. module: l10n_es_account_invoice_sequence
#: model:ir.model.fields,help:l10n_es_account_invoice_sequence.field_account_bank_statement_import_journal_creation__invoice_sequence_id
#: model:ir.model.fields,help:l10n_es_account_invoice_sequence.field_account_journal__invoice_sequence_id
msgid "The sequence used for invoice numbers in this journal."
msgstr ""

#. module: l10n_es_account_invoice_sequence
#: model:ir.model.fields,help:l10n_es_account_invoice_sequence.field_account_bank_statement_import_journal_creation__refund_inv_sequence_id
#: model:ir.model.fields,help:l10n_es_account_invoice_sequence.field_account_journal__refund_inv_sequence_id
msgid "The sequence used for refund invoices numbers in this journal."
msgstr ""

