# Translation of Odoo Server.
# This file contains the translation of the following modules:
#	* account_invoice_tax_required
#
msgid ""
msgstr ""
"Project-Id-Version: Odoo Server 8.0\n"
"Report-Msgid-Bugs-To: \n"
"POT-Creation-Date: 2015-06-15 11:36+0000\n"
"PO-Revision-Date: 2015-06-15 11:36+0000\n"
"Last-Translator: <>\n"
"Language-Team: \n"
"MIME-Version: 1.0\n"
"Content-Type: text/plain; charset=UTF-8\n"
"Content-Transfer-Encoding: \n"
"Plural-Forms: \n"

#. module: account_invoice_tax_required
#: model:ir.model,name:account_invoice_tax_required.model_account_invoice
msgid "Invoice"
msgstr ""

#. module: account_invoice_tax_required
#: code:addons/account_invoice_tax_required/models/account_invoice.py:29
#, python-format
msgid "Invoice have a line with product %s with no taxes"
msgstr ""

#. module: account_invoice_tax_required
#: code:addons/account_invoice_tax_required/models/account_invoice.py:39
#, python-format
msgid "No Taxes Defined!"
msgstr ""