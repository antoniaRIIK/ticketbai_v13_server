Cuando se valide una factura, la secuencia que se utilizará será la configurada
en el campo "Secuencia de factura" en lugar de la "Secuencia de asiento".

En caso de crear una nueva compañía e instalar un plan contable español, la
creación de los diarios se hará también con las secuencias correctamente
definidas.
