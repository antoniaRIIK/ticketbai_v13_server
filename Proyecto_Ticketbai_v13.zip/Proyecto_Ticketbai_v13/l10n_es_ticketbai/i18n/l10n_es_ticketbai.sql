# Translation of Odoo Server.
# This file contains the translation of the following modules:
#	* l10n_es_ticketbai
#
msgid ""
msgstr ""
"Project-Id-Version: Odoo Server 11.0\n"
"Report-Msgid-Bugs-To: \n"
"POT-Creation-Date: 2021-01-12 09:02+0000\n"
"PO-Revision-Date: 2021-01-12 09:02+0000\n"
"Last-Translator: <>\n"
"Language-Team: \n"
"MIME-Version: 1.0\n"
"Content-Type: text/plain; charset=UTF-8\n"
"Content-Transfer-Encoding: \n"
"Plural-Forms: \n"

#. module: l10n_es_ticketbai
#: model:ir.ui.view,arch_db:l10n_es_ticketbai.res_config_settings_view_form_inherit
msgid "<span class=\"fa fa-lg fa-desktop\" title=\"Values set here are company-specific\" groups=\"base.group_multi_company\"/>"
msgstr ""

#. module: l10n_es_ticketbai
#: selection:account.invoice,tbai_refund_key:0
msgid "Art. 80 - other"
msgstr ""

#. module: l10n_es_ticketbai
#: selection:account.invoice,tbai_refund_key:0
msgid "Art. 80.1, 80.2, 80.6 and rights founded error"
msgstr ""

#. module: l10n_es_ticketbai
#: selection:account.invoice,tbai_refund_key:0
msgid "Art. 80.3"
msgstr ""

#. module: l10n_es_ticketbai
#: selection:account.invoice,tbai_refund_key:0
msgid "Art. 80.4"
msgstr ""

#. module: l10n_es_ticketbai
#: model:ir.model.fields,help:l10n_es_ticketbai.field_account_invoice_tbai_refund_key
msgid "BOE-A-1992-28740. Ley 37/1992, de 28 de diciembre, del Impuesto sobre el Valor Añadido. Artículo 80. Modificación de la base imponible."
msgstr ""

#. module: l10n_es_ticketbai
#: selection:tbai.response,state:0
msgid "Build error"
msgstr ""

#. module: l10n_es_ticketbai
#: selection:account.invoice,tbai_refund_type:0
msgid "By differences"
msgstr ""

#. module: l10n_es_ticketbai
#: selection:account.invoice,tbai_refund_type:0
msgid "By substitution"
msgstr ""

#. module: l10n_es_ticketbai
#: code:addons/l10n_es_ticketbai/models/account_invoice.py:254
#, python-format
msgid "Cancellation"
msgstr ""

#. module: l10n_es_ticketbai
#: selection:tbai.invoice,state:0
#: selection:tbai.invoice.customer.cancellation,state:0
#: selection:tbai.invoice.customer.invoice,state:0
msgid "Cancelled"
msgstr ""

#. module: l10n_es_ticketbai
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_res_company_tbai_certificate_id
msgid "Certificate"
msgstr ""

#. module: l10n_es_ticketbai
#: code:addons/l10n_es_ticketbai/models/ticketbai_invoice.py:53
#, python-format
msgid "Certificate credentials"
msgstr ""

#. module: l10n_es_ticketbai
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_tbai_response_message_code
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_tbai_tax_map_code
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_tbai_vat_exemption_key_code
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_tbai_vat_regime_key_code
msgid "Code"
msgstr ""

#. module: l10n_es_ticketbai
#: model:ir.model,name:l10n_es_ticketbai.model_res_company
msgid "Companies"
msgstr ""

#. module: l10n_es_ticketbai
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_tbai_info_company_id
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_tbai_invoice_company_id
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_tbai_invoice_customer_cancellation_company_id
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_tbai_invoice_customer_invoice_company_id
#: model:ir.ui.view,arch_db:l10n_es_ticketbai.tbai_invoice_customer_cancellation_search
#: model:ir.ui.view,arch_db:l10n_es_ticketbai.tbai_invoice_customer_invoice_search
msgid "Company"
msgstr ""

#. module: l10n_es_ticketbai
#: code:addons/l10n_es_ticketbai/models/res_company.py:101
#, python-format
msgid "Company %s Device Serial Number longer than expected, 30 characters max!"
msgstr ""

#. module: l10n_es_ticketbai
#: code:addons/l10n_es_ticketbai/models/account_invoice.py:339
#, python-format
msgid "Company %s VAT number should not be empty!"
msgstr ""

#. module: l10n_es_ticketbai
#: model:ir.model,name:l10n_es_ticketbai.model_res_partner
msgid "Contact"
msgstr ""

#. module: l10n_es_ticketbai
#: code:addons/l10n_es_ticketbai/models/account_invoice_tax.py:319
#, python-format
msgid "Country code for partner %s not found!"
msgstr ""

#. module: l10n_es_ticketbai
#: code:addons/l10n_es_ticketbai/models/account_invoice.py:489
#, python-format
msgid "Country code not found for partner %s!"
msgstr ""

#. module: l10n_es_ticketbai
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_account_fiscal_position_tbai_tax_create_uid
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_account_fiscal_position_tbai_tax_template_create_uid
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_tbai_info_create_uid
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_tbai_invoice_customer_cancellation_create_uid
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_tbai_invoice_customer_invoice_create_uid
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_tbai_response_create_uid
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_tbai_response_message_create_uid
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_tbai_tax_agency_create_uid
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_tbai_tax_agency_version_create_uid
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_tbai_tax_map_create_uid
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_tbai_vat_exemption_key_create_uid
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_tbai_vat_regime_key_create_uid
msgid "Created by"
msgstr ""

#. module: l10n_es_ticketbai
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_account_fiscal_position_tbai_tax_create_date
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_account_fiscal_position_tbai_tax_template_create_date
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_tbai_info_create_date
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_tbai_invoice_customer_cancellation_create_date
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_tbai_invoice_customer_invoice_create_date
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_tbai_response_create_date
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_tbai_response_message_create_date
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_tbai_tax_agency_create_date
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_tbai_tax_agency_version_create_date
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_tbai_tax_map_create_date
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_tbai_vat_exemption_key_create_date
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_tbai_vat_regime_key_create_date
msgid "Created on"
msgstr ""

#. module: l10n_es_ticketbai
#: model:ir.model,name:l10n_es_ticketbai.model_account_invoice_refund
msgid "Credit Note"
msgstr ""

#. module: l10n_es_ticketbai
#: model:ir.ui.view,arch_db:l10n_es_ticketbai.tbai_invoice_customer_cancellation_search
#: model:ir.ui.view,arch_db:l10n_es_ticketbai.tbai_invoice_customer_invoice_search
msgid "Customer"
msgstr ""

#. module: l10n_es_ticketbai
#: model:ir.ui.view,arch_db:l10n_es_ticketbai.tbai_invoice_customer_cancellation_form
#: model:ir.ui.view,arch_db:l10n_es_ticketbai.tbai_invoice_customer_cancellation_search
#: model:ir.ui.view,arch_db:l10n_es_ticketbai.tbai_invoice_customer_cancellation_tree
msgid "Customer Cancellation"
msgstr ""

#. module: l10n_es_ticketbai
#: model:ir.ui.menu,name:l10n_es_ticketbai.menu_tbai_invoice_customer_cancellation
#: model:ir.ui.view,arch_db:l10n_es_ticketbai.invoice_form_inherit
msgid "Customer Cancellations"
msgstr ""

#. module: l10n_es_ticketbai
#: model:ir.ui.view,arch_db:l10n_es_ticketbai.tbai_invoice_customer_invoice_form
#: model:ir.ui.view,arch_db:l10n_es_ticketbai.tbai_invoice_customer_invoice_search
#: model:ir.ui.view,arch_db:l10n_es_ticketbai.tbai_invoice_customer_invoice_tree
msgid "Customer Invoice"
msgstr ""

#. module: l10n_es_ticketbai
#: model:ir.ui.menu,name:l10n_es_ticketbai.menu_tbai_invoice_customer_invoice
#: model:ir.ui.view,arch_db:l10n_es_ticketbai.invoice_form_inherit
msgid "Customer Invoices"
msgstr ""

#. module: l10n_es_ticketbai
#: model:ir.ui.view,arch_db:l10n_es_ticketbai.res_config_settings_view_form_inherit
msgid "Customer Invoicing Device Serial Number. As of TicketBAI v1.1, is not required."
msgstr ""

#. module: l10n_es_ticketbai
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_tbai_invoice_customer_cancellation_datas
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_tbai_invoice_customer_invoice_datas
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_tbai_invoice_datas
msgid "Datas"
msgstr ""

#. module: l10n_es_ticketbai
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_tbai_tax_agency_version_date_from
msgid "Date from"
msgstr ""

#. module: l10n_es_ticketbai
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_tbai_tax_agency_version_date_to
msgid "Date to"
msgstr ""

#. module: l10n_es_ticketbai
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_tbai_response_message_description
msgid "Description"
msgstr ""

#. module: l10n_es_ticketbai
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_res_company_tbai_developer_id
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_tbai_info_developer_id
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_tbai_info_name
msgid "Developer"
msgstr ""

#. module: l10n_es_ticketbai
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_res_company_tbai_device_serial_number
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_res_config_settings_tbai_device_serial_number
#: model:ir.ui.view,arch_db:l10n_es_ticketbai.res_config_settings_view_form_inherit
msgid "Device Serial Number"
msgstr ""

#. module: l10n_es_ticketbai
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_account_fiscal_position_tbai_tax_display_name
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_account_fiscal_position_tbai_tax_template_display_name
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_tbai_info_display_name
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_tbai_invoice_customer_cancellation_display_name
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_tbai_invoice_customer_invoice_display_name
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_tbai_invoice_display_name
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_tbai_response_display_name
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_tbai_response_message_display_name
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_tbai_tax_agency_display_name
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_tbai_tax_agency_version_display_name
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_tbai_tax_map_display_name
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_tbai_vat_exemption_key_display_name
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_tbai_vat_regime_key_display_name
msgid "Display Name"
msgstr ""

#. module: l10n_es_ticketbai
#: selection:tbai.invoice,state:0
#: selection:tbai.invoice.customer.cancellation,state:0
#: selection:tbai.invoice.customer.invoice,state:0
msgid "Draft"
msgstr ""

#. module: l10n_es_ticketbai
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_account_invoice_tbai_enabled
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_res_company_tbai_enabled
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_res_config_settings_tbai_enabled
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_res_partner_tbai_enabled
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_res_users_tbai_enabled
msgid "Enable TicketBAI"
msgstr ""

#. module: l10n_es_ticketbai
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_res_company_tbai_test_enabled
msgid "Enable testing"
msgstr ""

#. module: l10n_es_ticketbai
#: code:addons/l10n_es_ticketbai/models/ticketbai_tax_agency.py:105
#, python-format
msgid "Error! The dates of the record overlap with an existing record."
msgstr ""

#. module: l10n_es_ticketbai
#: model:ir.ui.view,arch_db:l10n_es_ticketbai.tbai_invoice_customer_cancellation_form
#: model:ir.ui.view,arch_db:l10n_es_ticketbai.tbai_invoice_customer_invoice_form
msgid "File"
msgstr ""

#. module: l10n_es_ticketbai
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_tbai_invoice_customer_cancellation_datas_fname
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_tbai_invoice_customer_invoice_datas_fname
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_tbai_invoice_datas_fname
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_tbai_response_xml_fname
msgid "File Name"
msgstr ""

#. module: l10n_es_ticketbai
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_tbai_invoice_customer_cancellation_file_size
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_tbai_invoice_customer_invoice_file_size
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_tbai_invoice_file_size
msgid "File Size"
msgstr ""

#. module: l10n_es_ticketbai
#: model:ir.ui.view,arch_db:l10n_es_ticketbai.invoice_form_inherit
msgid "Files Sent"
msgstr ""

#. module: l10n_es_ticketbai
#: model:ir.model,name:l10n_es_ticketbai.model_account_fiscal_position
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_account_fiscal_position_tbai_tax_position_id
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_account_fiscal_position_tbai_tax_template_position_id
msgid "Fiscal Position"
msgstr ""

#. module: l10n_es_ticketbai
#: model:ir.actions.act_window,name:l10n_es_ticketbai.action_tbai_account_fiscal_position_template
#: model:ir.ui.menu,name:l10n_es_ticketbai.menu_tbai_account_fiscal_position_template
#: model:ir.ui.view,arch_db:l10n_es_ticketbai.tbai_account_fiscal_position_template_view_form
#: model:ir.ui.view,arch_db:l10n_es_ticketbai.tbai_account_fiscal_position_template_view_search
#: model:ir.ui.view,arch_db:l10n_es_ticketbai.tbai_account_fiscal_position_template_view_tree
msgid "Fiscal Position Template"
msgstr ""

#. module: l10n_es_ticketbai
#: model:ir.ui.menu,name:l10n_es_ticketbai.menu_finance_ticketbai_general_info
msgid "General Info"
msgstr ""

#. module: l10n_es_ticketbai
#: model:ir.ui.view,arch_db:l10n_es_ticketbai.tbai_invoice_customer_cancellation_search
#: model:ir.ui.view,arch_db:l10n_es_ticketbai.tbai_invoice_customer_invoice_search
msgid "Group By"
msgstr ""

#. module: l10n_es_ticketbai
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_account_fiscal_position_tbai_tax_id
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_account_fiscal_position_tbai_tax_template_id
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_tbai_info_id
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_tbai_invoice_customer_cancellation_id
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_tbai_invoice_customer_invoice_id
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_tbai_invoice_id
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_tbai_response_id
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_tbai_response_message_id
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_tbai_tax_agency_id
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_tbai_tax_agency_version_id
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_tbai_tax_map_id
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_tbai_vat_exemption_key_id
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_tbai_vat_regime_key_id
msgid "ID"
msgstr ""

#. module: l10n_es_ticketbai
#: code:addons/l10n_es_ticketbai/models/res_partner.py:159
#, python-format
msgid "Identification type code required for %s"
msgstr ""

#. module: l10n_es_ticketbai
#: code:addons/l10n_es_ticketbai/models/res_partner.py:208
#, python-format
msgid "Invalid Complete Address format for %s. Should be 250 characters max.!"
msgstr ""

#. module: l10n_es_ticketbai
#: code:addons/l10n_es_ticketbai/models/res_partner.py:171
#, python-format
msgid "Invalid TicketBAI Partner Identification Number format for %s. Should be 20 characters max.!"
msgstr ""

#. module: l10n_es_ticketbai
#: code:addons/l10n_es_ticketbai/models/res_partner.py:117
#, python-format
msgid "Invalid VAT number format for %s!"
msgstr ""

#. module: l10n_es_ticketbai
#: code:addons/l10n_es_ticketbai/models/res_partner.py:188
#, python-format
msgid "Invalid Zip code format for %s. Should be 20 characters max.!"
msgstr ""

#. module: l10n_es_ticketbai
#: code:addons/l10n_es_ticketbai/models/ticketbai_response.py:44
#: model:ir.model,name:l10n_es_ticketbai.model_account_invoice
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_tbai_response_invoice_id
#: model:ir.ui.view,arch_db:l10n_es_ticketbai.tbai_invoice_customer_cancellation_form
#: model:ir.ui.view,arch_db:l10n_es_ticketbai.tbai_invoice_customer_invoice_form
#, python-format
msgid "Invoice"
msgstr ""

#. module: l10n_es_ticketbai
#: code:addons/l10n_es_ticketbai/models/account_invoice_tax.py:256
#, python-format
msgid "Invoice %s should have at least one group of not exempted taxes!"
msgstr ""

#. module: l10n_es_ticketbai
#: code:addons/l10n_es_ticketbai/models/account_invoice_tax.py:164
#, python-format
msgid "Invoice %s should have maximum 2 not subject to tax groups!"
msgstr ""

#. module: l10n_es_ticketbai
#: code:addons/l10n_es_ticketbai/models/account_invoice_tax.py:342
#, python-format
msgid "Invoice %s tax line %s should have exemption key!"
msgstr ""

#. module: l10n_es_ticketbai
#: code:addons/l10n_es_ticketbai/models/account_invoice.py:80
#, python-format
msgid "Invoice %s. You cannot change to draft a numbered invoice!"
msgstr ""

#. module: l10n_es_ticketbai
#: model:ir.model,name:l10n_es_ticketbai.model_account_invoice_line
msgid "Invoice Line"
msgstr ""

#. module: l10n_es_ticketbai
#: code:addons/l10n_es_ticketbai/models/account_invoice.py:520
#, python-format
msgid "Invoice Number %s Prefix longer than expected, 20 characters max.!"
msgstr ""

#. module: l10n_es_ticketbai
#: code:addons/l10n_es_ticketbai/models/account_invoice.py:540
#, python-format
msgid "Invoice Number %s longer than expected, 20 characters max!"
msgstr ""

#. module: l10n_es_ticketbai
#: code:addons/l10n_es_ticketbai/models/account_invoice.py:535
#, python-format
msgid "Invoice Number Prefix %s is not part of Invoice Number %s!"
msgstr ""

#. module: l10n_es_ticketbai
#: model:ir.model,name:l10n_es_ticketbai.model_account_invoice_tax
msgid "Invoice Tax"
msgstr ""

#. module: l10n_es_ticketbai
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_res_company_tbai_last_invoice_id
msgid "Last Invoice"
msgstr ""

#. module: l10n_es_ticketbai
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_account_fiscal_position_tbai_tax___last_update
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_account_fiscal_position_tbai_tax_template___last_update
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_tbai_info___last_update
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_tbai_invoice___last_update
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_tbai_invoice_customer_cancellation___last_update
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_tbai_invoice_customer_invoice___last_update
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_tbai_response___last_update
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_tbai_response_message___last_update
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_tbai_tax_agency___last_update
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_tbai_tax_agency_version___last_update
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_tbai_tax_map___last_update
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_tbai_vat_exemption_key___last_update
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_tbai_vat_regime_key___last_update
msgid "Last Modified on"
msgstr ""

#. module: l10n_es_ticketbai
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_account_fiscal_position_tbai_tax_template_write_uid
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_account_fiscal_position_tbai_tax_write_uid
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_tbai_info_write_uid
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_tbai_invoice_customer_cancellation_write_uid
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_tbai_invoice_customer_invoice_write_uid
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_tbai_response_message_write_uid
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_tbai_response_write_uid
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_tbai_tax_agency_version_write_uid
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_tbai_tax_agency_write_uid
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_tbai_tax_map_write_uid
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_tbai_vat_exemption_key_write_uid
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_tbai_vat_regime_key_write_uid
msgid "Last Updated by"
msgstr ""

#. module: l10n_es_ticketbai
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_account_fiscal_position_tbai_tax_template_write_date
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_account_fiscal_position_tbai_tax_write_date
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_tbai_info_write_date
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_tbai_invoice_customer_cancellation_write_date
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_tbai_invoice_customer_invoice_write_date
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_tbai_response_message_write_date
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_tbai_response_write_date
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_tbai_tax_agency_version_write_date
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_tbai_tax_agency_write_date
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_tbai_tax_map_write_date
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_tbai_vat_exemption_key_write_date
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_tbai_vat_regime_key_write_date
msgid "Last Updated on"
msgstr ""

#. module: l10n_es_ticketbai
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_res_company_tbai_license_key
msgid "License Key"
msgstr ""

#. module: l10n_es_ticketbai
#: model:ir.model.fields,help:l10n_es_ticketbai.field_account_invoice_tbai_substitution_invoice_id
msgid "Link between a validated Customer Invoice and its substitute."
msgstr ""

#. module: l10n_es_ticketbai
#: code:addons/l10n_es_ticketbai/models/account_invoice_tax.py:217
#, python-format
msgid "Maximum number of exempted invoice tax lines for invoice %s is 7!"
msgstr ""

#. module: l10n_es_ticketbai
#: code:addons/l10n_es_ticketbai/models/account_invoice_tax.py:280
#, python-format
msgid "Maximum number of invoice tax lines for invoice %s is 6!"
msgstr ""

#. module: l10n_es_ticketbai
#: model:ir.ui.view,arch_db:l10n_es_ticketbai.invoice_form_inherit
msgid "Messages"
msgstr ""

#. module: l10n_es_ticketbai
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_tbai_invoice_customer_cancellation_name
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_tbai_invoice_customer_invoice_name
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_tbai_invoice_name
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_tbai_tax_map_name
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_tbai_vat_exemption_key_name
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_tbai_vat_regime_key_name
msgid "Name"
msgstr ""

#. module: l10n_es_ticketbai
#: code:addons/l10n_es_ticketbai/models/res_partner.py:131
#, python-format
msgid "Name %s too long. Should be 120 characters max.!"
msgstr ""

#. module: l10n_es_ticketbai
#: selection:res.partner,tbai_partner_idtype:0
msgid "Official identification document issued by the country or territory of residence"
msgstr ""

#. module: l10n_es_ticketbai
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_account_invoice_tbai_date_operation
msgid "Operation Date"
msgstr ""

#. module: l10n_es_ticketbai
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_account_invoice_tbai_description_operation
msgid "Operation Description"
msgstr ""

#. module: l10n_es_ticketbai
#: code:addons/l10n_es_ticketbai/models/account_invoice.py:652
#, python-format
msgid "Operation Description for invoice %s should be 250 characters max.!"
msgstr ""

#. module: l10n_es_ticketbai
#: code:addons/l10n_es_ticketbai/models/account_invoice.py:649
#, python-format
msgid "Operation Description required for invoice %s!"
msgstr ""

#. module: l10n_es_ticketbai
#: selection:res.partner,tbai_partner_idtype:0
msgid "Other document"
msgstr ""

#. module: l10n_es_ticketbai
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_tbai_invoice_customer_cancellation_partner_id
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_tbai_invoice_customer_invoice_partner_id
msgid "Partner"
msgstr ""

#. module: l10n_es_ticketbai
#: selection:res.partner,tbai_partner_idtype:0
msgid "Passport"
msgstr ""

#. module: l10n_es_ticketbai
#: selection:tbai.invoice,state:0
#: selection:tbai.invoice.customer.cancellation,state:0
#: selection:tbai.invoice.customer.invoice,state:0
msgid "Pending"
msgstr ""

#. module: l10n_es_ticketbai
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_tbai_invoice_customer_cancellation_qr
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_tbai_invoice_customer_invoice_qr
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_tbai_invoice_qr
msgid "QR"
msgstr ""

#. module: l10n_es_ticketbai
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_tbai_tax_agency_qr_base_url
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_tbai_tax_agency_version_qr_base_url
msgid "QR Base URL"
msgstr ""

#. module: l10n_es_ticketbai
#: model:ir.ui.view,arch_db:l10n_es_ticketbai.tbai_invoice_customer_invoice_form
msgid "QR Code"
msgstr ""

#. module: l10n_es_ticketbai
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_tbai_tax_agency_rest_url_customer_cancellation
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_tbai_tax_agency_version_rest_url_customer_cancellation
msgid "REST API URL for Customer Invoice Cancellations"
msgstr ""

#. module: l10n_es_ticketbai
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_tbai_tax_agency_rest_url_customer_invoice
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_tbai_tax_agency_version_rest_url_customer_invoice
msgid "REST API URL for Customer Invoices"
msgstr ""

#. module: l10n_es_ticketbai
#: selection:tbai.response,state:0
msgid "Received"
msgstr ""

#. module: l10n_es_ticketbai
#: model:ir.ui.view,arch_db:l10n_es_ticketbai.invoice_form_inherit
msgid "Refund"
msgstr ""

#. module: l10n_es_ticketbai
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_res_company_tbai_vat_regime_simplified
msgid "Regime Simplified"
msgstr ""

#. module: l10n_es_ticketbai
#: model:ir.model.fields,help:l10n_es_ticketbai.field_res_company_tbai_software_name
msgid "Registered name at the Tax Agency."
msgstr ""

#. module: l10n_es_ticketbai
#: selection:tbai.response,state:0
msgid "Rejected"
msgstr ""

#. module: l10n_es_ticketbai
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_tbai_invoice_customer_cancellation_invoice_id
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_tbai_invoice_customer_invoice_invoice_id
msgid "Related Invoice"
msgstr ""

#. module: l10n_es_ticketbai
#: selection:tbai.response,state:0
msgid "Request error"
msgstr ""

#. module: l10n_es_ticketbai
#: code:addons/l10n_es_ticketbai/models/ticketbai_response.py:53
#, python-format
msgid "Required Fields missing"
msgstr ""

#. module: l10n_es_ticketbai
#: selection:res.partner,tbai_partner_idtype:0
msgid "Residence certificate"
msgstr ""

#. module: l10n_es_ticketbai
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_account_invoice_tbai_response_ids
#: model:ir.ui.view,arch_db:l10n_es_ticketbai.invoice_form_inherit
msgid "Responses"
msgstr ""

#. module: l10n_es_ticketbai
#: selection:tbai.invoice,state:0
#: selection:tbai.invoice.customer.cancellation,state:0
#: selection:tbai.invoice.customer.invoice,state:0
msgid "Sent"
msgstr ""

#. module: l10n_es_ticketbai
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_tbai_invoice_customer_cancellation_signature_value
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_tbai_invoice_customer_invoice_signature_value
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_tbai_invoice_signature_value
msgid "Signature Value"
msgstr ""

#. module: l10n_es_ticketbai
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_tbai_info_software
msgid "Software"
msgstr ""

#. module: l10n_es_ticketbai
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_res_company_tbai_software_name
msgid "Software Name"
msgstr ""

#. module: l10n_es_ticketbai
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_tbai_invoice_customer_cancellation_state
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_tbai_invoice_customer_invoice_state
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_tbai_invoice_state
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_tbai_response_state
msgid "State"
msgstr ""

#. module: l10n_es_ticketbai
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_account_invoice_tbai_substitute_simplified_invoice
msgid "Substitute Simplified Invoice"
msgstr ""

#. module: l10n_es_ticketbai
#: code:addons/l10n_es_ticketbai/models/account_invoice.py:407
#, python-format
msgid "Substituted Invoice for invoice %s not found!"
msgstr ""

#. module: l10n_es_ticketbai
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_tbai_invoice_customer_cancellation_tbai_identifier
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_tbai_invoice_customer_invoice_tbai_identifier
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_tbai_invoice_tbai_identifier
msgid "TBAI Identifier"
msgstr ""

#. module: l10n_es_ticketbai
#: model:ir.model,name:l10n_es_ticketbai.model_account_tax
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_account_fiscal_position_tbai_tax_tax_id
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_account_fiscal_position_tbai_tax_template_tax_id
msgid "Tax"
msgstr ""

#. module: l10n_es_ticketbai
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_res_company_tbai_tax_agency_id
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_tbai_tax_agency_name
msgid "Tax Agency"
msgstr ""

#. module: l10n_es_ticketbai
#: code:addons/l10n_es_ticketbai/models/res_partner.py:75
#, python-format
msgid "Tax Agency %s requires Customer Address!"
msgstr ""

#. module: l10n_es_ticketbai
#: code:addons/l10n_es_ticketbai/models/res_partner.py:69
#, python-format
msgid "Tax Agency %s requires Customer Zip code!"
msgstr ""

#. module: l10n_es_ticketbai
#: code:addons/l10n_es_ticketbai/models/account_invoice.py:441
#, python-format
msgid "Tax Agency %s requires Invoice details for invoice %s!"
msgstr ""

#. module: l10n_es_ticketbai
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_tbai_tax_agency_tax_agency_version_ids
msgid "Tax Agency Version"
msgstr ""

#. module: l10n_es_ticketbai
#: sql_constraint:account.fiscal.position.tbai.tax:0
#: sql_constraint:account.fiscal.position.tbai.tax.template:0
#: code:addons/l10n_es_ticketbai/models/account_fiscal_position.py:34
#: code:addons/l10n_es_ticketbai/models/chart_template.py:35
#, python-format
msgid "Tax must be unique per fiscal position!"
msgstr ""

#. module: l10n_es_ticketbai
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_tbai_tax_map_tax_template_ids
#: model:ir.ui.view,arch_db:l10n_es_ticketbai.tbai_tax_map_view_form
msgid "Taxes"
msgstr ""

#. module: l10n_es_ticketbai
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_account_invoice_tbai_datetime_invoice
msgid "Tbai Datetime Invoice"
msgstr ""

#. module: l10n_es_ticketbai
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_tbai_info_tbai_enabled
msgid "Tbai Enabled"
msgstr ""

#. module: l10n_es_ticketbai
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_account_invoice_tbai_previous_invoice_id
msgid "Tbai Previous Invoice"
msgstr ""

#. module: l10n_es_ticketbai
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_account_invoice_tbai_refund_key
msgid "Tbai Refund Key"
msgstr ""

#. module: l10n_es_ticketbai
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_account_invoice_tbai_refund_type
msgid "Tbai Refund Type"
msgstr ""

#. module: l10n_es_ticketbai
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_tbai_response_message_tbai_response_id
msgid "Tbai Response"
msgstr ""

#. module: l10n_es_ticketbai
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_tbai_response_tbai_response_message_ids
msgid "Tbai Response Message"
msgstr ""

#. module: l10n_es_ticketbai
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_account_invoice_tbai_substitution_invoice_id
msgid "Tbai Substitution Invoice"
msgstr ""

#. module: l10n_es_ticketbai
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_tbai_tax_agency_version_tbai_tax_agency_id
msgid "Tbai Tax Agency"
msgstr ""

#. module: l10n_es_ticketbai
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_account_fiscal_position_tbai_vat_exemption_ids
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_account_fiscal_position_template_tbai_vat_exemption_ids
msgid "Tbai Vat Exemption"
msgstr ""

#. module: l10n_es_ticketbai
#: model:ir.model,name:l10n_es_ticketbai.model_account_fiscal_position_template
msgid "Template for Fiscal Position"
msgstr ""

#. module: l10n_es_ticketbai
#: model:ir.model,name:l10n_es_ticketbai.model_account_chart_template
msgid "Templates for Account Chart"
msgstr ""

#. module: l10n_es_ticketbai
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_tbai_tax_agency_test_rest_url_customer_cancellation
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_tbai_tax_agency_version_test_rest_url_customer_cancellation
msgid "Test - REST API URL for Customer Invoice Cancellations"
msgstr ""

#. module: l10n_es_ticketbai
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_tbai_tax_agency_test_rest_url_customer_invoice
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_tbai_tax_agency_version_test_rest_url_customer_invoice
msgid "Test - REST API URL for Customer Invoices"
msgstr ""

#. module: l10n_es_ticketbai
#: model:ir.ui.menu,name:l10n_es_ticketbai.menu_finance_ticketbai
#: model:ir.ui.menu,name:l10n_es_ticketbai.menu_l10n_es_tbai_config
#: model:ir.ui.view,arch_db:l10n_es_ticketbai.invoice_form_inherit
#: model:ir.ui.view,arch_db:l10n_es_ticketbai.res_config_settings_view_form_inherit
#: model:ir.ui.view,arch_db:l10n_es_ticketbai.view_account_position_form_inherit
#: model:ir.ui.view,arch_db:l10n_es_ticketbai.view_company_form_inherit
#: model:ir.ui.view,arch_db:l10n_es_ticketbai.view_partner_property_form_inherit
msgid "TicketBAI"
msgstr ""

#. module: l10n_es_ticketbai
#: model:ir.actions.act_window,name:l10n_es_ticketbai.action_ticketbai_general_info
msgid "TicketBAI - General Info"
msgstr ""

#. module: l10n_es_ticketbai
#: model:ir.actions.server,name:l10n_es_ticketbai.ir_cron_l10n_es_ticketbai_send_pending_invoices_ir_actions_server
#: model:ir.cron,cron_name:l10n_es_ticketbai.ir_cron_l10n_es_ticketbai_send_pending_invoices
#: model:ir.cron,name:l10n_es_ticketbai.ir_cron_l10n_es_ticketbai_send_pending_invoices
msgid "TicketBAI - Send pending invoices"
msgstr ""

#. module: l10n_es_ticketbai
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_account_invoice_tax_tbai_vat_exemption_key
msgid "TicketBAI - VAT Exemption Key"
msgstr ""

#. module: l10n_es_ticketbai
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_tbai_invoice_api_url
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_tbai_invoice_customer_cancellation_api_url
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_tbai_invoice_customer_invoice_api_url
msgid "TicketBAI API URL"
msgstr ""

#. module: l10n_es_ticketbai
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_account_invoice_tbai_cancellation_id
msgid "TicketBAI Cancellation"
msgstr ""

#. module: l10n_es_ticketbai
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_account_invoice_tbai_cancellation_ids
msgid "TicketBAI Cancellations"
msgstr ""

#. module: l10n_es_ticketbai
#: model:ir.ui.view,arch_db:l10n_es_ticketbai.tbai_account_fiscal_position_template_view_search
msgid "TicketBAI Exemption 2nd Key"
msgstr ""

#. module: l10n_es_ticketbai
#: model:ir.ui.view,arch_db:l10n_es_ticketbai.tbai_account_fiscal_position_template_view_search
msgid "TicketBAI Exemption 3rd Key"
msgstr ""

#. module: l10n_es_ticketbai
#: model:ir.ui.view,arch_db:l10n_es_ticketbai.tbai_account_fiscal_position_template_view_search
msgid "TicketBAI Exemption Key"
msgstr ""

#. module: l10n_es_ticketbai
#: model:ir.actions.act_window,name:l10n_es_ticketbai.action_tbai_vat_exemption_key
#: model:ir.ui.view,arch_db:l10n_es_ticketbai.tbai_vat_exemption_key_view_search
#: model:ir.ui.view,arch_db:l10n_es_ticketbai.tbai_vat_exemption_key_view_tree
msgid "TicketBAI Exemption Keys"
msgstr ""

#. module: l10n_es_ticketbai
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_res_partner_tbai_partner_idtype
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_res_users_tbai_partner_idtype
msgid "TicketBAI Identification Type Code"
msgstr ""

#. module: l10n_es_ticketbai
#: model:ir.ui.view,arch_db:l10n_es_ticketbai.view_ticketbai_info_form
msgid "TicketBAI Info"
msgstr ""

#. module: l10n_es_ticketbai
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_account_invoice_tbai_invoice_id
msgid "TicketBAI Invoice"
msgstr ""

#. module: l10n_es_ticketbai
#: code:addons/l10n_es_ticketbai/models/ticketbai_invoice.py:189
#, python-format
msgid "TicketBAI Invoice %s Error: TBAI identifier %s should be %d characters long with CRC-8!"
msgstr ""

#. module: l10n_es_ticketbai
#: code:addons/l10n_es_ticketbai/models/ticketbai_invoice.py:180
#, python-format
msgid "TicketBAI Invoice %s Error: TBAI identifier without CRC-8 %s should be %d characters long!"
msgstr ""

#. module: l10n_es_ticketbai
#: code:addons/l10n_es_ticketbai/models/account_invoice_tax.py:37
#, python-format
msgid "TicketBAI Invoice %s Error: Tax %s contains multiple Equivalence Surcharge Taxes"
msgstr ""

#. module: l10n_es_ticketbai
#: code:addons/l10n_es_ticketbai/models/account_invoice_tax.py:46
#, python-format
msgid "TicketBAI Invoice %s Error: the Invoice should have one tax line for Tax %s"
msgstr ""

#. module: l10n_es_ticketbai
#: model:ir.actions.act_window,name:l10n_es_ticketbai.action_tbai_invoice_customer_cancellation
msgid "TicketBAI Invoice - Customer Cancellation"
msgstr ""

#. module: l10n_es_ticketbai
#: model:ir.actions.act_window,name:l10n_es_ticketbai.action_tbai_invoice_customer_invoice
msgid "TicketBAI Invoice - Customer Invoice"
msgstr ""

#. module: l10n_es_ticketbai
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_account_invoice_tbai_invoice_ids
#: model:ir.ui.menu,name:l10n_es_ticketbai.menu_tbai_invoices
msgid "TicketBAI Invoices"
msgstr ""

#. module: l10n_es_ticketbai
#: code:addons/l10n_es_ticketbai/models/res_company.py:72
#, python-format
msgid "TicketBAI License Key for company %s should be 20 characters max.!"
msgstr ""

#. module: l10n_es_ticketbai
#: code:addons/l10n_es_ticketbai/models/res_company.py:68
#, python-format
msgid "TicketBAI License Key for company %s should not be empty!"
msgstr ""

#. module: l10n_es_ticketbai
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_res_partner_tbai_partner_identification_number
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_res_users_tbai_partner_identification_number
msgid "TicketBAI Partner Identification Number"
msgstr ""

#. module: l10n_es_ticketbai
#: code:addons/l10n_es_ticketbai/models/res_partner.py:176
#, python-format
msgid "TicketBAI Partner Identification Number for %s should not be empty!"
msgstr ""

#. module: l10n_es_ticketbai
#: code:addons/l10n_es_ticketbai/models/account_invoice.py:588
#, python-format
msgid "TicketBAI Refund Key is required for invoice %s!"
msgstr ""

#. module: l10n_es_ticketbai
#: code:addons/l10n_es_ticketbai/models/account_invoice.py:600
#, python-format
msgid "TicketBAI Refund Type is required for invoice %s!"
msgstr ""

#. module: l10n_es_ticketbai
#: model:ir.actions.act_window,name:l10n_es_ticketbai.action_tbai_vat_regime_key
#: model:ir.ui.view,arch_db:l10n_es_ticketbai.tbai_vat_regime_key_view_search
#: model:ir.ui.view,arch_db:l10n_es_ticketbai.tbai_vat_regime_key_view_tree
msgid "TicketBAI Registration Keys"
msgstr ""

#. module: l10n_es_ticketbai
#: model:ir.model,name:l10n_es_ticketbai.model_tbai_tax_agency
msgid "TicketBAI Tax Agency"
msgstr ""

#. module: l10n_es_ticketbai
#: model:ir.model,name:l10n_es_ticketbai.model_tbai_tax_agency_version
msgid "TicketBAI Tax Agency - version"
msgstr ""

#. module: l10n_es_ticketbai
#: model:ir.actions.act_window,name:l10n_es_ticketbai.action_tbai_tax_map
#: model:ir.model,name:l10n_es_ticketbai.model_tbai_tax_map
#: model:ir.ui.menu,name:l10n_es_ticketbai.menu_tbai_tax_map
#: model:ir.ui.view,arch_db:l10n_es_ticketbai.tbai_tax_map_view_form
#: model:ir.ui.view,arch_db:l10n_es_ticketbai.tbai_tax_map_view_tree
msgid "TicketBAI Tax Map"
msgstr ""

#. module: l10n_es_ticketbai
#: code:addons/l10n_es_ticketbai/models/account_invoice.py:451
#, python-format
msgid "TicketBAI VAT 1st regime key required for invoice %s!"
msgstr ""

#. module: l10n_es_ticketbai
#: model:ir.model,name:l10n_es_ticketbai.model_tbai_vat_exemption_key
#: model:ir.ui.menu,name:l10n_es_ticketbai.menu_tbai_vat_exemption_key
msgid "TicketBAI VAT Exemption mapping keys"
msgstr ""

#. module: l10n_es_ticketbai
#: model:ir.model,name:l10n_es_ticketbai.model_tbai_vat_regime_key
#: model:ir.ui.menu,name:l10n_es_ticketbai.menu_tbai_vat_regime_key
msgid "TicketBAI VAT Regime mapping keys"
msgstr ""

#. module: l10n_es_ticketbai
#: model:ir.ui.view,arch_db:l10n_es_ticketbai.view_ticketbai_info_form
msgid "TicketBAI is disabled."
msgstr ""

#. module: l10n_es_ticketbai
#: code:addons/l10n_es_ticketbai/models/ticketbai_invoice.py:55
#, python-format
msgid "TicketBAI missing required fields: %s"
msgstr ""

#. module: l10n_es_ticketbai
#: code:addons/l10n_es_ticketbai/models/account_invoice.py:163
#, python-format
msgid "TicketBAI refund by differences only available for Customer Credit Notes."
msgstr ""

#. module: l10n_es_ticketbai
#: code:addons/l10n_es_ticketbai/models/account_invoice.py:152
#, python-format
msgid "TicketBAI refund by substitution only available for Customer Invoices."
msgstr ""

#. module: l10n_es_ticketbai
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_tbai_tax_agency_version
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_tbai_tax_agency_version_version
msgid "TicketBAI version"
msgstr ""

#. module: l10n_es_ticketbai
#: code:addons/l10n_es_ticketbai/models/ticketbai_tax_agency.py:75
#, python-format
msgid "TicketBAI version max size is 5 characters."
msgstr ""

#. module: l10n_es_ticketbai
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_tbai_invoice_customer_cancellation_qr_url
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_tbai_invoice_customer_invoice_qr_url
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_tbai_invoice_qr_url
msgid "URL"
msgstr ""

#. module: l10n_es_ticketbai
#: code:addons/l10n_es_ticketbai/models/ticketbai_response.py:107
#, python-format
msgid "Unknown TicketBAI response code."
msgstr ""

#. module: l10n_es_ticketbai
#: model:ir.model.fields,help:l10n_es_ticketbai.field_res_partner_tbai_partner_identification_number
#: model:ir.model.fields,help:l10n_es_ticketbai.field_res_users_tbai_partner_identification_number
msgid "Used when the identification type code is not VAT identification number."
msgstr ""

#. module: l10n_es_ticketbai
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_account_fiscal_position_tbai_tax_tbai_vat_exemption_key
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_account_fiscal_position_tbai_tax_template_tbai_vat_exemption_key
msgid "VAT Exemption Key"
msgstr ""

#. module: l10n_es_ticketbai
#: model:ir.ui.view,arch_db:l10n_es_ticketbai.tbai_account_fiscal_position_template_view_form
#: model:ir.ui.view,arch_db:l10n_es_ticketbai.view_account_position_form_inherit
#: model:ir.ui.view,arch_db:l10n_es_ticketbai.view_account_position_template_form_inherit
msgid "VAT Exemptions"
msgstr ""

#. module: l10n_es_ticketbai
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_account_fiscal_position_tbai_vat_regime_key2
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_account_fiscal_position_template_tbai_vat_regime_key2
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_account_invoice_tbai_vat_regime_key2
msgid "VAT Regime 2nd Key"
msgstr ""

#. module: l10n_es_ticketbai
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_account_fiscal_position_tbai_vat_regime_key3
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_account_fiscal_position_template_tbai_vat_regime_key3
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_account_invoice_tbai_vat_regime_key3
msgid "VAT Regime 3rd Key"
msgstr ""

#. module: l10n_es_ticketbai
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_account_fiscal_position_tbai_vat_regime_key
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_account_fiscal_position_template_tbai_vat_regime_key
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_account_invoice_tbai_vat_regime_key
msgid "VAT Regime Key"
msgstr ""

#. module: l10n_es_ticketbai
#: model:ir.ui.view,arch_db:l10n_es_ticketbai.invoice_form_inherit
#: model:ir.ui.view,arch_db:l10n_es_ticketbai.tbai_account_fiscal_position_template_view_form
#: model:ir.ui.view,arch_db:l10n_es_ticketbai.view_account_position_form_inherit
msgid "VAT Regimes"
msgstr ""

#. module: l10n_es_ticketbai
#: selection:res.partner,tbai_partner_idtype:0
msgid "VAT identification number"
msgstr ""

#. module: l10n_es_ticketbai
#: code:addons/l10n_es_ticketbai/models/res_company.py:56
#: code:addons/l10n_es_ticketbai/models/res_partner.py:58
#: code:addons/l10n_es_ticketbai/models/res_partner.py:92
#, python-format
msgid "VAT number or another type of identification for %s is required!"
msgstr ""

#. module: l10n_es_ticketbai
#: code:addons/l10n_es_ticketbai/models/account_invoice.py:151
#: code:addons/l10n_es_ticketbai/models/account_invoice.py:162
#, python-format
msgid "Warning"
msgstr ""

#. module: l10n_es_ticketbai
#: model:ir.model.fields,field_description:l10n_es_ticketbai.field_tbai_response_xml
msgid "XML Response"
msgstr ""

#. module: l10n_es_ticketbai
#: model:ir.model,name:l10n_es_ticketbai.model_account_fiscal_position_tbai_tax
msgid "account.fiscal.position.tbai.tax"
msgstr ""

#. module: l10n_es_ticketbai
#: model:ir.model,name:l10n_es_ticketbai.model_account_fiscal_position_tbai_tax_template
msgid "account.fiscal.position.tbai.tax.template"
msgstr ""

#. module: l10n_es_ticketbai
#: model:ir.model,name:l10n_es_ticketbai.model_l10n_es_aeat_certificate
msgid "l10n.es.aeat.certificate"
msgstr ""

#. module: l10n_es_ticketbai
#: model:ir.model,name:l10n_es_ticketbai.model_res_config_settings
msgid "res.config.settings"
msgstr ""

#. module: l10n_es_ticketbai
#: model:ir.model,name:l10n_es_ticketbai.model_tbai_info
msgid "tbai.info"
msgstr ""

#. module: l10n_es_ticketbai
#: model:ir.model,name:l10n_es_ticketbai.model_tbai_invoice
msgid "tbai.invoice"
msgstr ""

#. module: l10n_es_ticketbai
#: model:ir.model,name:l10n_es_ticketbai.model_tbai_invoice_customer_cancellation
msgid "tbai.invoice.customer.cancellation"
msgstr ""

#. module: l10n_es_ticketbai
#: model:ir.model,name:l10n_es_ticketbai.model_tbai_invoice_customer_invoice
msgid "tbai.invoice.customer.invoice"
msgstr ""

#. module: l10n_es_ticketbai
#: model:ir.model,name:l10n_es_ticketbai.model_tbai_response
msgid "tbai.response"
msgstr ""

#. module: l10n_es_ticketbai
#: model:ir.model,name:l10n_es_ticketbai.model_tbai_response_message
msgid "tbai.response.message"
msgstr ""

