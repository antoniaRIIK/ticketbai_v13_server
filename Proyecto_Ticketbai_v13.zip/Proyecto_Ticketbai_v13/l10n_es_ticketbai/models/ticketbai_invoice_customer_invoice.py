# Copyright 2020 Binovo IT Human Project SL
# License AGPL-3.0 or later (https://www.gnu.org/licenses/agpl).
from datetime import datetime
from collections import OrderedDict
from ..ticketbai.xml_schema import XMLSchema, TicketBaiInvoiceTypeEnum
from .ticketbai_invoice import TicketBaiQRParams, TicketBaiIdentifierValuesIndex
from odoo import models, fields, api


class TicketBaiInvoiceCustomerInvoice(models.Model):
    _name = 'tbai.invoice.customer.invoice'
    _inherit = 'tbai.invoice'

    def send(self, **kwargs):
        self.ensure_one()
        return super().send(move_id=self.move_id.id, **kwargs)

    def recreate(self):
        self.mapped('move_id').tbai_rebuild_customer_invoice()

    move_id = fields.Many2one(
        comodel_name='account.move', string='Related Invoice', required=True,
        ondelete='restrict')
    partner_id = fields.Many2one(
        comodel_name='res.partner', related='move_id.partner_id', readonly=True,
        store=True)

    def __init__(self, pool, cr):
        super(TicketBaiInvoiceCustomerInvoice, self).__init__(pool, cr)
        type(self).TicketBAIXMLSchema = XMLSchema(
            TicketBaiInvoiceTypeEnum.customer_invoice)

    @api.depends(
        'company_id', 'company_id.tbai_tax_agency_id',
        'company_id.tbai_tax_agency_id.rest_url_customer_invoice',
        'company_id.tbai_tax_agency_id.test_rest_url_customer_invoice'
    )
    def _compute_api_url(self):
        for record in self:
            if record.company_id.tbai_test_enabled:
                url = record.company_id.tbai_tax_agency_id.\
                    test_rest_url_customer_invoice
            else:
                url = record.company_id.tbai_tax_agency_id.rest_url_customer_invoice
            record.api_url = url

    def _get_tbai_identifier_values(self):
        self.ensure_one()
        res = super()._get_tbai_identifier_values()
        invoice_date = self.move_id.tbai_get_value_fecha_expedicion_factura()
        res[TicketBaiIdentifierValuesIndex.invoice_date.value] = \
            datetime.strptime(invoice_date, "%d-%m-%Y").strftime("%d%m%y")
        return res

    def _get_qr_url_values(self):
        self.ensure_one()
        res = super()._get_qr_url_values()
        res[TicketBaiQRParams.invoice_number_prefix.value] = \
            self.move_id.tbai_get_value_serie_factura()
        res[TicketBaiQRParams.invoice_number.value] = \
            self.move_id.tbai_get_value_num_factura()
        res[TicketBaiQRParams.invoice_total_amount.value] = \
            self.move_id.tbai_get_value_importe_total_factura()
        return res

    def tbai_build_sujetos(self):
        return OrderedDict([
            ("Emisor", self.move_id.tbai_build_emisor()),
            ("Destinatarios", self.move_id.tbai_build_destinatarios())
        ])

    def tbai_build_factura(self):
        return OrderedDict([
            ("CabeceraFactura", self.move_id.tbai_build_cabecera_factura()),
            ("DatosFactura", self.move_id.tbai_build_datos_factura()),
            ("TipoDesglose", self.move_id.tbai_build_tipo_desglose()),
        ])

    def tbai_build_huella_tbai(self):
        res = OrderedDict({})
        encadenamiento_factura_anterior = \
            self.move_id.tbai_build_encadenamiento_factura_anterior()
        if encadenamiento_factura_anterior:
            res["EncadenamientoFacturaAnterior"] = encadenamiento_factura_anterior
        res["Software"] = self.company_id.tbai_build_software()
        num_serie_dispositivo = self.company_id.tbai_get_value_num_serie_dispositivo()
        if num_serie_dispositivo:
            res["NumSerieDispositivo"] = num_serie_dispositivo
        return res
